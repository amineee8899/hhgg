require('dotenv').config();
const express = require('express');
const TelegramBot = require('node-telegram-bot-api');
const app = express();
app.use(express.json());

// Initialize bot
const bot = new TelegramBot(process.env.BOT_TOKEN, {polling: true});

// Security middleware
const authMiddleware = (req, res, next) => {
  if(req.headers.authorization !== `Bearer ${process.env.API_SECRET}`) {
    return res.status(401).json({error: 'Unauthorized'});
  }
  next();
};

// Message queue system
const messageQueue = [];
let isProcessing = false;

async function processQueue() {
  if (isProcessing || messageQueue.length === 0) return;
  
  isProcessing = true;
  const { message, res } = messageQueue.shift();
  
  try {
    const result = await bot.sendMessage(process.env.CHAT_ID, message);
    res.json({ success: true, message_id: result.message_id });
  } catch (error) {
    console.error('Send Error:', error.message);
    res.status(500).json({ success: false, error: error.message });
  }
  
  isProcessing = false;
  processQueue();
}

app.post('/send', authMiddleware, async (req, res) => {
  const message = req.body.message?.trim();
  
  if (!message) {
    return res.status(400).json({error: 'Empty message'});
  }

  messageQueue.push({ message, res });
  processQueue();
});

app.listen(3000, () => console.log('Server running on port 3000'));